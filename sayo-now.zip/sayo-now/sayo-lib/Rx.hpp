#pragma once

int R0      = 4;
int R1      = 5;
int R2      = 6;
int R3      = 7;
int P8_R0   = 11;
int P8_R1   = 12;
int P8_R2   = 13;
int P8_R3   = 14;
int P16_R0  = 48;
int P16_R1  = 49;
int P16_R2  = 50;
int P16_R3  = 51;
int P32_R0  = 56;
int P32_R1  = 57;
int P32_R2  = 58;
int P32_R3  = 59;

// Note that when read/write Pb_Rx, Rx must align with b/8 in bytes



#define get_array_8(Rx,i,tar) { \
    Rx+=i;        \
    tar=P8_##Rx;  \
    Rx-=i;        \
}
#define set_array_8(Rx,i,num) {\
    Rx+=i;        \
    P8_##Rx=num;  \
    Rx-=i;        \
}

#define get_array_16(Rx,i,tar) { \
    Rx+=i<<1;     \
    tar=P16_##Rx; \
    Rx-=i<<1;     \
}
#define set_array_16(Rx,i,num) {\
    Rx+=i<<1;     \
    P16_##Rx=num; \
    Rx-=i<<1;     \
}

#define get_array_32(Rx,i,tar) { \
    Rx+=i<<2;     \
    tar=P32_##Rx; \
    Rx-=i<<2;     \
}
#define set_array_32(Rx,i,num) {\
    Rx+=i<<2;     \
    P32_##Rx=num; \
    Rx-=i<<2;     \
}

