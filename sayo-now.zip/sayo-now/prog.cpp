#include "sayo-lib/prog.hpp"
int x=4;            // assign x with address 4
int xx=x;           // assign xx with address of x
                    // same as "int xx=__addr(x);"
int y=5;    
int func(int y=6);  //function declaration
int func2(int x=ARG0);  //reuse ARG0, see below for reasons
int A0=ARG0;
int func3(int x=A0);    //shorter, maybe easier

// the entrance of the program
// Assign the addresses of ARGx to Vx, 
// such that their values will be pushed into stack to avoid being changed
// (after every function call, they will be recovered from the stack)
// and for functions with no more than 4, AND 8-BIT ARGUMENTS,
//      you can reuse the addresses of ARGx (ARGx is an 8-bit variable)
// It's recommended to do so for every program,
//      unless you know what you are doing!
// However, Vx will be pushed into stack every function call (like func and func3 in this case)
//      and make code size larger
//      so only write down Vx you really use
int main(int V1=ARG1, int V0=ARG0){   //order doesn't matter
    x=func(123+123)*456;  
    x+=V0+V1;
    x=(x<10);
    y=func3(x*70)+80;
    swap(x,y);                // as shown in prog.hpp
    return x||y;
}
int func(int x=6){  // function definition: symbol may have different names, 
                    // but no different addressed
    int y=7;
    return x*3;
}
int func2(int x=ARG0){
    return x;
}
int func3(int x=ARG0){  //only need to make sure addresses don't conflict
    return func2(x);
}